"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  MessageSquare,
  Send,
  Sparkles,
  RefreshCw,
  User,
  ShieldCheck,
  ChevronRight,
} from "lucide-react";
import { motion } from "motion/react";
import { renderMarkdown } from "../lib/markdown";

interface Message {
  role: "user" | "model";
  content: string;
}

interface TheoScreenProps {
  preloadedPrompt: string;
  clearPreloadedPrompt: () => void;
}

export default function TheoScreen({ preloadedPrompt, clearPreloadedPrompt }: TheoScreenProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      content: "Olá! Sou o **Theo IA**, seu tutor e assistente clínico inteligente. Como posso apoiar sua decisão diagnóstica ou terapêutica hoje?\n\nSinta-se à vontade para enviar um caso clínico, perguntar sobre o ajuste posológico de fármacos em pacientes com falência de órgãos ou discutir as diretrizes mais recentes.",
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Suggestions chips for quick clinical context loading
  const clinicalSuggestions = [
    {
      label: "Crise Hipertensiva",
      prompt: "Como deve ser o manejo de uma Crise Hipertensiva (Urgência vs. Emergência Hipertensiva)? Cite as principais drogas de escolha e a velocidade segura de redução da pressão arterial.",
    },
    {
      label: "Ajuste iSGLT2 na DRC",
      prompt: "Quais são as regras de corte para início e manutenção de inibidores de SGLT2 (como Empagliflozina ou Dapagliflozina) de acordo com o Ritmo de Filtração Glomerular (eGFR)?",
    },
    {
      label: "Dose da Enoxaparina",
      prompt: "Qual é a dose recomendada de Enoxaparina para anticoagulação plena em pacientes com Fibrilação Atrial e como devo ajustar essa dosagem caso o Clearance de Creatinina seja inferior a 30 ml/min?",
    },
  ];

  // Handle preloaded prompt from other screens (like Guidelines)
  useEffect(() => {
    if (preloadedPrompt) {
      setTimeout(() => {
        setInputValue(preloadedPrompt);
        clearPreloadedPrompt();
      }, 0);
    }
  }, [preloadedPrompt, clearPreloadedPrompt]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isSending]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputValue;
    if (!text.trim() || isSending) return;

    const userMessage: Message = { role: "user", content: text };
    setMessages((prev) => [...prev, userMessage]);
    if (!textToSend) setInputValue("");
    setIsSending(true);

    try {
      // Package conversation history (only include the last 8 messages to keep the context size optimal)
      const conversationHistory = [...messages, userMessage].slice(-8).map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const response = await fetch("/api/gemini", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "chat",
          messages: conversationHistory,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setMessages((prev) => [
          ...prev,
          { role: "model", content: data.text || "Sem resposta da IA." },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          { role: "model", content: `❌ **Erro do Servidor**: ${data.error || "Não foi possível obter resposta de Theo IA."}` },
        ]);
      }
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        { role: "model", content: "❌ **Erro de Rede**: Por favor, verifique sua conexão com o servidor do Atlas IA." },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  const clearChat = () => {
    if (confirm("Deseja realmente limpar a conversa atual?")) {
      setMessages([
        {
          role: "model",
          content: "Conversa reiniciada. Sou o **Theo IA**, seu assistente clínico. Em que posso ajudar no seu plantão ou estudo hoje?",
        },
      ]);
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto h-[calc(100vh-140px)] md:h-[calc(100vh-80px)] flex flex-col justify-between text-[#f8f7f4] font-sans" id="theo-chat-container">
      {/* Suggestions and top layout bar */}
      <div className="space-y-3 shrink-0" id="theo-chat-header">
        <div className="flex items-center justify-between border-b border-[#f8f7f4]/10 pb-3">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 bg-[#433fe5]/15 text-[#433fe5] rounded-xl flex items-center justify-center border border-[#433fe5]/25">
              <MessageSquare className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <h4 className="font-bold text-white font-syne text-sm md:text-base">Theo IA • Tutor Médico</h4>
              <p className="text-[10px] text-[#f8f7f4]/40 font-semibold flex items-center gap-1 font-mono">
                <ShieldCheck className="h-3 w-3 text-emerald-500" />
                <span>Baseado em Consensos e Diretrizes Vigentes</span>
              </p>
            </div>
          </div>

          <button
            onClick={clearChat}
            className="p-2 text-[#f8f7f4]/45 hover:text-white hover:bg-[#f8f7f4]/5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer font-mono"
            title="Limpar Conversa"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Limpar Conversa</span>
          </button>
        </div>

        {/* Suggestion Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[10px] font-bold uppercase text-[#f8f7f4]/40 tracking-wider whitespace-nowrap font-mono">Dúvidas Frequentes:</span>
          {clinicalSuggestions.map((sug) => (
            <button
              key={sug.label}
              onClick={() => handleSendMessage(sug.prompt)}
              disabled={isSending}
              className="px-3 py-1.5 bg-[#111113] hover:bg-[#f8f7f4]/5 border border-[#f8f7f4]/10 rounded-lg text-xs text-[#f8f7f4]/80 font-semibold hover:text-[#433fe5] hover:border-[#433fe5]/30 cursor-pointer whitespace-nowrap shrink-0 transition-all flex items-center gap-1 disabled:opacity-50 font-mono"
            >
              <span>{sug.label}</span>
              <ChevronRight className="h-3 w-3 text-[#f8f7f4]/30" />
            </button>
          ))}
        </div>
      </div>

      {/* Message Feed Canvas */}
      <div className="flex-1 overflow-y-auto bg-[#0c0c0e] border border-[#f8f7f4]/10 rounded-2xl p-4 md:p-6 my-4 space-y-4" id="theo-message-feed">
        {messages.map((msg, i) => {
          const isModel = msg.role === "model";
          return (
            <div
              key={i}
              className={`flex items-start gap-3.5 max-w-[85%] md:max-w-[75%] ${isModel ? "mr-auto" : "ml-auto flex-row-reverse"}`}
            >
              <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 text-white font-bold text-xs ${
                isModel ? "bg-gradient-to-tr from-[#433fe5] to-[#7028e0] shadow-md border border-white/10" : "bg-[#111113] border border-[#f8f7f4]/15 text-white"
              }`}>
                {isModel ? "T" : <User className="h-4 w-4" />}
              </div>

              <div className={`p-4 rounded-2xl text-sm md:text-base leading-relaxed ${
                isModel
                  ? "bg-[#111113] border border-[#f8f7f4]/10 rounded-tl-sm text-[#f8f7f4]"
                  : "bg-[#433fe5] text-white rounded-tr-sm shadow-md"
              }`}>
                {isModel ? (
                  <div className="prose prose-invert max-w-none prose-sm leading-relaxed">
                    {renderMarkdown(msg.content)}
                  </div>
                ) : (
                  <p className="font-medium whitespace-pre-wrap">{msg.content}</p>
                )}
              </div>
            </div>
          );
        })}

        {isSending && (
          <div className="flex items-start gap-3.5 max-w-[75%] mr-auto">
            <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-[#433fe5] to-[#7028e0] flex items-center justify-center text-white shrink-0 animate-pulse border border-white/10">
              T
            </div>
            <div className="bg-[#111113] border border-[#f8f7f4]/10 p-4 rounded-2xl rounded-tl-sm text-sm text-[#f8f7f4]/70 flex items-center gap-2">
              <div className="flex space-x-1.5">
                <div className="h-2 w-2 bg-[#433fe5] rounded-full animate-bounce [animation-delay:-0.3s]" />
                <div className="h-2 w-2 bg-[#433fe5] rounded-full animate-bounce [animation-delay:-0.15s]" />
                <div className="h-2 w-2 bg-[#433fe5] rounded-full animate-bounce" />
              </div>
              <span className="font-semibold text-xs ml-1 font-mono">Theo IA está redigindo parecer...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Form Bar */}
      <div className="bg-[#111113] border border-[#f8f7f4]/10 p-2 md:p-3 rounded-2xl shrink-0" id="theo-chat-input-area">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={isSending}
            placeholder="Digite sua dúvida diagnóstica, caso clínico ou posologia..."
            className="flex-1 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-xl px-4 py-3 text-sm text-[#f8f7f4] placeholder-[#f8f7f4]/30 focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5] transition-all"
          />

          <button
            type="submit"
            disabled={!inputValue.trim() || isSending}
            className="p-3 bg-[#433fe5] hover:bg-[#322fbe] disabled:bg-[#0c0c0e] disabled:text-[#f8f7f4]/20 disabled:border-[#f8f7f4]/10 text-white rounded-xl transition-all shadow-md cursor-pointer shrink-0"
          >
            <Send className="h-4.5 w-4.5" />
          </button>
        </form>
      </div>
    </div>
  );
}
