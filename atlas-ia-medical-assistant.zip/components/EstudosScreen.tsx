"use client";

import React, { useState } from "react";
import {
  Award,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  GraduationCap,
  HelpCircle,
  Lightbulb,
  Sparkles,
  TrendingUp,
  XCircle,
  RotateCcw,
} from "lucide-react";
import { motion } from "motion/react";
import { renderMarkdown } from "../lib/markdown";

interface Question {
  id: number;
  specialty: string;
  source: string;
  text: string;
  options: { key: string; text: string }[];
  correctKey: string;
  explanationPredefined: string;
}

export default function EstudosScreen() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  // AI Explanation State
  const [isExplaining, setIsExplaining] = useState(false);
  const [aiExplanation, setAiExplanation] = useState("");
  const [explanationError, setExplanationError] = useState("");

  const questions: Question[] = [
    {
      id: 1,
      specialty: "Cardiologia / Emergência",
      source: "Simulado TEC / SBC 2026",
      text: "Paciente masculino, 68 anos, admitido no pronto-socorro com dispneia súbita e ortopneia graves. Sinais vitais: PA 184/108 mmHg, FC 114 bpm, FR 28 irpm, SatO₂ 86% em ar ambiente. À ausculta, apresenta estertores crepitantes bilaterais até terço superior e presença de B3. Qual é a conduta inicial imediata mais adequada de acordo com as diretrizes de insuficiência cardíaca aguda?",
      options: [
        { key: "A", text: "Início imediato de Dobutamina endovenosa e expansão volêmica cautelosa." },
        { key: "B", text: "Oxigenoterapia sob máscara de reservatório, Furosemida EV e Nitroprussiato de Sódio ou Nitroglicerina EV." },
        { key: "C", text: "Administração de Metoprolol EV imediato para controle de frequência cardíaca." },
        { key: "D", text: "Anticoagulação plena imediata com Enoxaparina e suspensão de qualquer terapia diurética." },
      ],
      correctKey: "B",
      explanationPredefined: "O paciente apresenta quadro clínico clássico de Insuficiência Cardíaca Aguda de perfil B (quente e congestionado), manifestando-se como Edema Agudo de Pulmão (EAP) hipertensivo. A conduta imediata envolve oxigenação (frequentemente VNI), diuréticos de alça intravenosos (Furosemida) para reduzir volemia, e vasodilatadores intravenosos (Nitroprussiato de Sódio ou Nitroglicerina) para reduzir rapidamente a pós-carga e aliviar o trabalho ventricular.",
    },
    {
      id: 2,
      specialty: "Nefrologia / Farmacologia",
      source: "Revalida INEP",
      text: "Um paciente de 62 anos com Diabetes Mellitus tipo 2 e Doença Renal Crônica Estágio 3b (Filtração Glomerular estimada de 38 mL/min/1.73m²) inicia uso de Dapagliflozina 10mg/dia para proteção cardiorrenal. Após 14 dias, exames de controle revelam elevação de 18% na creatinina sérica basal (de 1.7 mg/dL para 2.01 mg/dL) com potássio sérico estável (4.4 mEq/L). Qual é a conduta recomendada?",
      options: [
        { key: "A", text: "Suspender imediatamente a Dapagliflozina devido à nefrotoxicidade aguda severa." },
        { key: "B", text: "Substituir Dapagliflozina por metformina em dose plena de 2000mg ao dia." },
        { key: "C", text: "Manter a Dapagliflozina e monitorar o paciente, pois elevações de até 30% na creatinina são esperadas e representam efeito hemodinâmico de proteção a longo prazo." },
        { key: "D", text: "Iniciar diálise de urgência imediata e prescrever bicarbonato de sódio." },
      ],
      correctKey: "C",
      explanationPredefined: "Os inibidores de SGLT2 (como Dapagliflozina) causam uma queda hemodinâmica inicial na filtração glomerular devido ao restabelecimento do feedback tubuloglomerular e consequente vasoconstrição da arteríola aferente (redução da hiperfiltração glomerular). Um aumento da creatinina sérica de até 30% em relação ao valor basal nas primeiras 2 a 4 semanas é esperado, reversível e prediz proteção renal a longo prazo. A medicação deve ser mantida caso o potássio esteja estável e não haja outras causas de lesão renal aguda associada.",
    },
    {
      id: 3,
      specialty: "Endocrinologia",
      source: "Prova Nacional de Residência Médica",
      text: "Paciente feminina, 45 anos, com queixa de fadiga crônica, ganho de peso e constipação. Exames laboratoriais revelam TSH de 14.5 mIU/L (Valor de Referência: 0.4 a 4.5) e T4 Livre de 0.6 ng/dL (Valor de Referência: 0.8 a 1.8). Qual o diagnóstico correto e a dose inicial padrão recomendada de Levotiroxina para esta paciente sem cardiopatias prévias?",
      options: [
        { key: "A", text: "Hipotireoidismo Subclínico; iniciar Levotiroxina 12.5 mcg/dia." },
        { key: "B", text: "Hipotireoidismo Primário Clínico; iniciar Levotiroxina em dose plena de substituição de aproximadamente 1.6 mcg/kg/dia." },
        { key: "C", text: "Tireoidite Subaguda; iniciar Prednisona 40mg/dia e suspender propiltiuracil." },
        { key: "D", text: "Hipertireoidismo Secundário; iniciar Tapazol 20mg/dia." },
      ],
      correctKey: "B",
      explanationPredefined: "A paciente apresenta hipotireoidismo primário clínico estabelecido (TSH elevado acima de 10 e T4 livre baixo). Em pacientes jovens e sem comorbidades cardíacas de relevo, a conduta recomendada é iniciar o tratamento diretamente com dose plena de substituição de Levotiroxina, estimada em cerca de 1.6 mcg/kg de peso ideal ao dia, administrada em jejum, para atingir o eutiroidismo clínico e laboratorial.",
    },
  ];

  const currentQuestion = questions[currentQuestionIndex];

  const handleOptionSelect = (key: string) => {
    if (isConfirmed) return;
    setSelectedOption(key);
  };

  const handleConfirm = () => {
    if (!selectedOption || isConfirmed) return;
    setIsConfirmed(true);
    const isCorrect = selectedOption === currentQuestion.correctKey;
    setScore((prev) => ({
      correct: isCorrect ? prev.correct + 1 : prev.correct,
      total: prev.total + 1,
    }));
  };

  const handleNextQuestion = () => {
    setSelectedOption(null);
    setIsConfirmed(false);
    setAiExplanation("");
    setExplanationError("");
    setCurrentQuestionIndex((prev) => (prev + 1) % questions.length);
  };

  const askAiExplanation = async () => {
    setIsExplaining(true);
    setExplanationError("");
    setAiExplanation("");

    const promptText = `Como tutor acadêmico do Centro de Estudos Atlas IA, explique detalhadamente a seguinte questão médica:
Pergunta: "${currentQuestion.text}"
Opções fornecidas:
${currentQuestion.options.map((o) => `- Opção [${o.key}]: ${o.text}`).join("\n")}
A resposta correta é a Opção [${currentQuestion.correctKey}].

Por favor, elabore uma explicação estruturada contendo:
1. Análise detalhada do caso clínico e fisiopatologia.
2. Por que a opção [${currentQuestion.correctKey}] está correta.
3. Análise detalhada de por que cada uma das outras opções está clinicamente incorreta.
4. Pérolas de consultório / dicas práticas de prova para este tema.`;

    try {
      const response = await fetch("/api/gemini", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "study_simulator",
          prompt: promptText,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setAiExplanation(data.text);
      } else {
        setExplanationError(data.error || "Não foi possível obter a explicação acadêmica da IA.");
      }
    } catch (err) {
      console.error(err);
      setExplanationError("Erro de comunicação com o servidor acadêmico.");
    } finally {
      setIsExplaining(false);
    }
  };

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto pb-24 text-[#f8f7f4]" id="estudos-container">
      {/* Grid: Stats and Performance (Top) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Study Stats Indicator */}
        <div className="lg:col-span-4 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 shadow-md space-y-4 flex flex-col justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-[#433fe5]/15 text-[#433fe5] rounded-lg border border-[#433fe5]/25">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div>
              <h4 className="font-bold text-white font-syne text-sm md:text-base">Métricas Acadêmicas</h4>
              <p className="text-xs text-[#f8f7f4]/40 font-mono">Seu progresso nos simulados de prova</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 py-1">
            <div className="bg-[#0c0c0e] border border-[#f8f7f4]/5 p-3 rounded-xl text-center">
              <span className="text-[10px] font-bold text-[#f8f7f4]/45 uppercase tracking-widest block font-mono">Respondidas</span>
              <span className="text-2xl font-extrabold text-white block mt-0.5">{score.total}</span>
            </div>
            <div className="bg-emerald-500/15 border border-emerald-500/25 p-3 rounded-xl text-center">
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest block font-mono">Acertos</span>
              <span className="text-2xl font-extrabold text-emerald-300 block mt-0.5">{score.correct}</span>
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs font-semibold text-[#f8f7f4]/70">
              <span>Taxa de Acertos Geral</span>
              <span>{score.total > 0 ? Math.round((score.correct / score.total) * 100) : 0}%</span>
            </div>
            <div className="w-full bg-[#0c0c0e] h-2 rounded-full overflow-hidden">
              <div
                className="bg-emerald-500 h-full transition-all duration-300"
                style={{ width: `${score.total > 0 ? (score.correct / score.total) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>

        {/* Custom SVG Study Progress Chart */}
        <div className="lg:col-span-8 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-emerald-500/15 text-emerald-400 rounded-lg">
                <TrendingUp className="h-5 w-5" />
              </div>
              <div>
                <h4 className="font-bold text-white font-syne text-sm md:text-base">Curva de Desempenho Semanal</h4>
                <p className="text-xs text-[#f8f7f4]/40 font-mono">Evolução do percentual de acerto acumulado</p>
              </div>
            </div>
            <div className="text-xs font-bold text-[#f8f7f4]/50 bg-[#0c0c0e] px-2.5 py-1 rounded-lg border border-[#f8f7f4]/5 font-mono">
              Meta: &gt; 80%
            </div>
          </div>

          {/* Clean, custom SVG chart */}
          <div className="h-28 w-full flex items-end justify-between px-2 pt-2" id="studies-svg-chart">
            <svg viewBox="0 0 500 100" className="w-full h-full text-[#f8f7f4]/10">
              {/* Background guidelines */}
              <line x1="0" y1="20" x2="500" y2="20" stroke="#f8f7f4" strokeWidth="1" strokeDasharray="4 4" strokeOpacity="0.05" />
              <line x1="0" y1="50" x2="500" y2="50" stroke="#f8f7f4" strokeWidth="1" strokeDasharray="4 4" strokeOpacity="0.05" />
              <line x1="0" y1="80" x2="500" y2="80" stroke="#f8f7f4" strokeWidth="1" strokeDasharray="4 4" strokeOpacity="0.05" />

              {/* Performance Line Path */}
              <path
                d="M 20 85 Q 100 55, 180 62 T 340 38 T 480 22"
                fill="none"
                stroke="#433fe5"
                strokeWidth="3.5"
                strokeLinecap="round"
              />

              {/* Performance Area Gradient */}
              <path
                d="M 20 85 Q 100 55, 180 62 T 340 38 T 480 22 L 480 100 L 20 100 Z"
                fill="url(#indigo-grad)"
                opacity="0.25"
              />

              {/* Data points */}
              <circle cx="20" cy="85" r="5" fill="#433fe5" stroke="#111113" strokeWidth="2" />
              <circle cx="100" cy="62" r="5" fill="#433fe5" stroke="#111113" strokeWidth="2" />
              <circle cx="180" cy="62" r="5" fill="#433fe5" stroke="#111113" strokeWidth="2" />
              <circle cx="260" cy="48" r="5" fill="#433fe5" stroke="#111113" strokeWidth="2" />
              <circle cx="340" cy="38" r="5" fill="#433fe5" stroke="#111113" strokeWidth="2" />
              <circle cx="420" cy="28" r="5" fill="#433fe5" stroke="#111113" strokeWidth="2" />
              <circle cx="480" cy="22" r="6" fill="#10b981" stroke="#111113" strokeWidth="2" />

              <defs>
                <linearGradient id="indigo-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#433fe5" />
                  <stop offset="100%" stopColor="#0c0c0e" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          <div className="flex justify-between text-[10px] text-[#f8f7f4]/40 font-bold px-2 pt-1 border-t border-[#f8f7f4]/10 font-mono">
            <span>Semana 21</span>
            <span>Semana 22</span>
            <span>Semana 23</span>
            <span>Semana 24</span>
            <span>Semana 25</span>
            <span>Semana 26</span>
            <span className="text-[#10b981]">Hoje (Sem 27)</span>
          </div>
        </div>
      </div>

      {/* Main Study Question Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="studies-question-canvas">
        {/* Question Panel (7 cols) */}
        <div className="lg:col-span-7 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            {/* Specialty tag */}
            <div className="flex items-center justify-between border-b border-[#f8f7f4]/10 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-[#f8f7f4] bg-[#433fe5]/30 px-2.5 py-1 rounded-full uppercase tracking-wider border border-[#433fe5]/40 font-mono">
                  {currentQuestion.specialty}
                </span>
                <span className="text-xs text-[#f8f7f4]/40 font-semibold">{currentQuestion.source}</span>
              </div>
              <span className="text-xs font-bold text-[#f8f7f4]/40 font-mono">Questão {currentQuestionIndex + 1} de {questions.length}</span>
            </div>

            {/* Question Text */}
            <p className="text-white text-sm md:text-base leading-relaxed font-bold font-syne">
              {currentQuestion.text}
            </p>

            {/* Options list */}
            <div className="space-y-2.5 pt-2">
              {currentQuestion.options.map((option) => {
                const isSelected = selectedOption === option.key;
                const isCorrect = option.key === currentQuestion.correctKey;
                let optionStyle = "border-[#f8f7f4]/10 text-[#f8f7f4]/80 bg-[#0c0c0e] hover:bg-[#f8f7f4]/5";

                if (isConfirmed) {
                  if (isCorrect) {
                    optionStyle = "border-emerald-500 bg-emerald-500/15 text-emerald-300";
                  } else if (isSelected) {
                    optionStyle = "border-rose-500 bg-rose-500/15 text-rose-300";
                  } else {
                    optionStyle = "border-[#f8f7f4]/5 text-[#f8f7f4]/30 opacity-50";
                  }
                } else if (isSelected) {
                  optionStyle = "border-[#433fe5] bg-[#433fe5]/15 text-white";
                }

                return (
                  <button
                    key={option.key}
                    onClick={() => handleOptionSelect(option.key)}
                    disabled={isConfirmed}
                    className={`w-full text-left p-4 rounded-xl border font-medium text-xs md:text-sm transition-all cursor-pointer flex items-start gap-3 ${optionStyle}`}
                  >
                    <span className={`h-6 w-6 rounded-lg font-bold flex items-center justify-center shrink-0 border ${
                      isConfirmed && isCorrect ? "bg-emerald-500 border-emerald-600 text-white" :
                      isConfirmed && isSelected ? "bg-rose-500 border-rose-600 text-white" :
                      isSelected ? "bg-[#433fe5] border-[#433fe5] text-white" :
                      "bg-[#0c0c0e] border-[#f8f7f4]/15 text-[#f8f7f4]/60"
                    }`}>
                      {option.key}
                    </span>
                    <span className="flex-1 mt-0.5">{option.text}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Confirmation & Navigation Row */}
          <div className="flex items-center justify-between gap-4 pt-4 border-t border-[#f8f7f4]/10">
            {!isConfirmed ? (
              <button
                onClick={handleConfirm}
                disabled={!selectedOption}
                className="bg-[#433fe5] hover:bg-[#322fbe] disabled:bg-[#0c0c0e] disabled:text-[#f8f7f4]/30 disabled:border-[#f8f7f4]/10 disabled:cursor-not-allowed text-white font-mono font-bold py-3 px-6 rounded-xl text-xs md:text-sm transition-all cursor-pointer shadow-md"
              >
                Confirmar Resposta
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 px-6 rounded-xl text-xs md:text-sm transition-all cursor-pointer flex items-center gap-1 shadow-md font-mono"
              >
                <span>Próxima Questão</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            )}

            {isConfirmed && (
              <button
                onClick={askAiExplanation}
                disabled={isExplaining}
                className="bg-[#433fe5]/15 hover:bg-[#433fe5]/25 border border-[#433fe5]/30 text-white font-mono font-bold py-3 px-5 rounded-xl text-xs md:text-sm transition-all cursor-pointer flex items-center gap-2"
              >
                {isExplaining ? (
                  <>
                    <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Tutor IA analisando...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4.5 w-4.5 text-white" />
                    <span>Explicar Fisiopatologia com IA</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Predefined & AI Explanation Panel (5 cols) */}
        <div className="lg:col-span-5 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md flex flex-col min-h-[350px]">
          <div className="flex items-center gap-2 border-b border-[#f8f7f4]/10 pb-3 mb-4 shrink-0">
            <div className="p-1.5 bg-[#433fe5]/10 text-[#433fe5] rounded-lg">
              <Lightbulb className="h-4.5 w-4.5 text-yellow-300" />
            </div>
            <div>
              <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base">Gabarito e Fisiopatologia</h4>
              <p className="text-[10px] text-[#f8f7f4]/40 font-mono">Fundamentos acadêmicos do consenso</p>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto space-y-4 text-xs md:text-sm leading-relaxed font-medium text-[#f8f7f4]/80">
            {isConfirmed ? (
              <div className="space-y-4">
                {/* Result alert banner */}
                <div className={`p-4 rounded-xl flex items-start gap-3 border ${
                  selectedOption === currentQuestion.correctKey
                    ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/25"
                    : "bg-rose-500/15 text-rose-300 border-rose-500/25"
                }`}>
                  {selectedOption === currentQuestion.correctKey ? (
                    <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <span className="font-bold text-sm">
                      {selectedOption === currentQuestion.correctKey ? "Parabéns, você acertou!" : "Resposta Incorreta"}
                    </span>
                    <p className="mt-0.5 text-xs font-mono">
                      A alternativa correta é a <strong className="font-bold uppercase text-[#433fe5]">Opção {currentQuestion.correctKey}</strong>.
                    </p>
                  </div>
                </div>

                {/* Predefined explanation */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-[#f8f7f4]/40 uppercase tracking-wider block font-mono">Gabarito Comentado</span>
                  <p className="text-[#f8f7f4]/85 bg-[#0c0c0e] p-3 rounded-lg border border-[#f8f7f4]/5">
                    {currentQuestion.explanationPredefined}
                  </p>
                </div>

                {/* Dynamic AI Explanation */}
                {isExplaining && (
                  <div className="flex flex-col items-center justify-center py-8 text-center space-y-3 bg-[#0c0c0e] border border-[#f8f7f4]/5 rounded-xl p-4">
                    <div className="h-9 w-9 rounded-xl bg-[#433fe5]/15 flex items-center justify-center relative">
                      <div className="absolute inset-0 rounded-xl border-2 border-[#433fe5] animate-ping opacity-25" />
                      <Sparkles className="h-5 w-5 text-[#433fe5] animate-pulse" />
                    </div>
                    <p className="text-xs text-[#f8f7f4]/40 max-w-xs font-mono">Theo IA está compilando a revisão fisiopatológica do assunto...</p>
                  </div>
                )}

                {aiExplanation && (
                  <div className="border-t border-[#f8f7f4]/10 pt-4 mt-4 space-y-3" id="studies-gemini-output">
                    <span className="text-xs font-bold text-white bg-[#433fe5]/35 px-2.5 py-1 rounded-lg border border-[#433fe5]/25 uppercase tracking-wider inline-flex items-center gap-1 font-mono">
                      <Sparkles className="h-3.5 w-3.5 text-yellow-300 animate-spin-slow" />
                      <span>Revisão do Tutor Theo IA</span>
                    </span>
                    <div className="prose prose-invert prose-sm leading-relaxed font-semibold text-[#f8f7f4]/90">
                      {renderMarkdown(aiExplanation)}
                    </div>
                  </div>
                )}

                {explanationError && (
                  <div className="p-3 bg-rose-500/15 text-rose-300 border border-rose-500/25 rounded-xl text-xs font-mono">
                    {explanationError}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-[#f8f7f4]/40 space-y-2">
                <HelpCircle className="h-10 w-10 text-[#f8f7f4]/30" />
                <h5 className="font-bold text-[#f8f7f4]/60">Resolva a questão</h5>
                <p className="text-xs max-w-xs mx-auto leading-relaxed">
                  Selecione uma das alternativas à esquerda e confirme para ver o gabarito comentado e poder solicitar o aprofundamento fisiopatológico de Theo IA.
                  </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
