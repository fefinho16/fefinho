"use client";

import React, { useState, useEffect } from "react";
import {
  Activity,
  Calculator,
  FileSpreadsheet,
  FileText,
  HeartPulse,
  Info,
  Layers,
  Sparkles,
  AlertTriangle,
  RotateCcw,
} from "lucide-react";
import { motion } from "motion/react";
import { renderMarkdown } from "../lib/markdown";

export default function AmbulatorioScreen() {
  // Tabs for sub-tools
  const [activeTab, setActiveTab] = useState<"ANALYSIS" | "CHA2DS2" | "CKD_EPI" | "LDL">("ANALYSIS");

  // 1. DYNAMIC CLINICAL REPORT STATE (Gemini Integrated)
  const [patientData, setPatientData] = useState({
    name: "Arnaldo Pires Ramos",
    age: "74",
    gender: "Masculino",
    systolicBP: "152",
    diastolicBP: "94",
    heartRate: "82",
    creatinine: "1.6",
    weight: "82",
    comorbidities: {
      has: true,
      dm: true,
      ic: true,
      drc: true,
      stroke: false,
    },
    symptoms: "Dispneia leve aos esforços, edema maleolar bilateral ++/4.",
  });

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [reportResult, setReportResult] = useState<string>("");
  const [analysisError, setAnalysisError] = useState("");

  const handleCheckboxChange = (key: keyof typeof patientData.comorbidities) => {
    setPatientData((prev) => ({
      ...prev,
      comorbidities: {
        ...prev.comorbidities,
        [key]: !prev.comorbidities[key],
      },
    }));
  };

  const runPatientAnalysis = async () => {
    setIsAnalyzing(true);
    setAnalysisError("");
    setReportResult("");

    try {
      const response = await fetch("/api/gemini", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          action: "analyze_patient",
          patientData,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setReportResult(data.text);
      } else {
        setAnalysisError(data.error || "Erro ao conectar-se à IA.");
      }
    } catch (err: any) {
      console.error(err);
      setAnalysisError("Erro de comunicação com o servidor de inteligência artificial.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // 2. CHA2DS2-VASC CALCULATOR STATE
  const [chaParams, setChaParams] = useState({
    chn: false, // Wait, keep the same properties but compute score on the fly
    chf: false, // Congestive Heart Failure (1)
    htn: false, // Hypertension (1)
    age75: false, // Age >= 75 (2)
    dm: false, // Diabetes (1)
    stroke: false, // Stroke/TIA/Thromboembolism (2)
    vascular: false, // Vascular Disease (MI, PAD, aortic plaque) (1)
    age65: false, // Age 65-74 (1)
    female: false, // Female sex (1)
  });

  // Calculate score directly during rendering (no state, no useEffect!)
  let chaScore = 0;
  if (chaParams.chf) chaScore += 1;
  if (chaParams.htn) chaScore += 1;
  if (chaParams.age75) chaScore += 2;
  if (chaParams.dm) chaScore += 1;
  if (chaParams.stroke) chaScore += 2;
  if (chaParams.vascular) chaScore += 1;
  if (!chaParams.age75 && chaParams.age65) chaScore += 1;
  if (chaParams.female) chaScore += 1;

  const resetCha = () => {
    setChaParams({
      chn: false,
      chf: false,
      htn: false,
      age75: false,
      dm: false,
      stroke: false,
      vascular: false,
      age65: false,
      female: false,
    });
  };

  const getChaRecommendation = (score: number, genderIsFemale: boolean) => {
    const adjustedScore = genderIsFemale ? score - 1 : score;
    if (adjustedScore >= 2) {
      return {
        text: "Anticoagulação ORAL recomendada (Recomendação Classe I). Preferência por NOACs (Apixabana, Rivaroxabana, Dabigatrana) se não houver contraindicação ou estenose mitral moderada-grave/valva mecânica.",
        variant: "danger",
      };
    } else if (adjustedScore === 1) {
      return {
        text: "Anticoagulação ORAL deve ser considerada (Recomendação Classe IIa). Individualizar risco de sangramento vs. benefício trombótico.",
        variant: "warning",
      };
    } else {
      return {
        text: "Sem indicação de terapia antitrombótica / anticoagulação (Recomendação Classe III). Apenas acompanhamento clínico.",
        variant: "success",
      };
    }
  };

  // 3. CKD-EPI (Glomerular Filtration Rate) STATE
  const [ckdParams, setCkdParams] = useState({
    creatinine: "1.2",
    age: "65",
    gender: "Feminino",
    raceBlack: false,
  });

  // Calculate GFR directly during rendering
  const getGfrResult = () => {
    const scr = parseFloat(ckdParams.creatinine);
    const ageVal = parseFloat(ckdParams.age);
    if (isNaN(scr) || isNaN(ageVal) || scr <= 0 || ageVal <= 0) {
      return null;
    }

    // CKD-EPI 2021 formula without race or 2009 with race (standard simplified version)
    const isFemale = ckdParams.gender === "Feminino";
    const k = isFemale ? 0.7 : 0.9;
    const alpha = isFemale ? -0.241 : -0.302;
    const genderCoeff = isFemale ? 1.012 : 1.0;
    const blackCoeff = ckdParams.raceBlack ? 1.159 : 1.0;

    const minFraction = Math.min(scr / k, 1);
    const maxFraction = Math.max(scr / k, 1);

    const gfr =
      141 *
      Math.pow(minFraction, alpha) *
      Math.pow(maxFraction, -1.2) *
      Math.pow(0.9938, ageVal) *
      genderCoeff *
      blackCoeff;

    const gfrRounded = Math.round(gfr * 10) / 10;

    let stage = "";
    let desc = "";

    if (gfrRounded >= 90) {
      stage = "Estágio G1";
      desc = "Função renal normal ou elevada.";
    } else if (gfrRounded >= 60) {
      stage = "Estágio G2";
      desc = "Redução leve da função renal.";
    } else if (gfrRounded >= 45) {
      stage = "Estágio G3a";
      desc = "Redução leve a moderada da função renal.";
    } else if (gfrRounded >= 30) {
      stage = "Estágio G3b";
      desc = "Redução moderada a grave da função renal.";
    } else if (gfrRounded >= 15) {
      stage = "Estágio G4";
      desc = "Redução grave da função renal.";
    } else {
      stage = "Estágio G5";
      desc = "Falência renal / Insuficiência renal terminal.";
    }

    return { gfr: gfrRounded, stage, desc };
  };

  const gfrResult = getGfrResult();

  // 4. LDL-C CALCULATOR STATE
  const [ldlParams, setLdlParams] = useState({
    totalChol: "210",
    hdl: "45",
    triglycerides: "160",
  });

  // Calculate LDL directly during rendering
  const getLdlResult = () => {
    const tc = parseFloat(ldlParams.totalChol);
    const hdlVal = parseFloat(ldlParams.hdl);
    const tg = parseFloat(ldlParams.triglycerides);

    if (!isNaN(tc) && !isNaN(hdlVal) && !isNaN(tg) && tc > 0 && hdlVal > 0 && tg > 0) {
      const calculated = tc - hdlVal - tg / 5;
      return Math.round(calculated * 10) / 10;
    }
    return null;
  };

  const ldlResult = getLdlResult();

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto pb-24 text-[#f8f7f4]" id="ambulatorio-container">
      {/* Sub-navigation tabs */}
      <div className="flex items-center gap-1 border-b border-[#f8f7f4]/10 overflow-x-auto pb-px" id="ambulatorio-tabs">
        <button
          onClick={() => setActiveTab("ANALYSIS")}
          className={`flex items-center gap-2 px-5 py-3 text-xs md:text-sm font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "ANALYSIS"
              ? "border-[#433fe5] text-white bg-[#433fe5]/15"
              : "border-transparent text-[#f8f7f4]/45 hover:text-[#f8f7f4] hover:bg-[#f8f7f4]/5"
          }`}
        >
          <Sparkles className="h-4.5 w-4.5" />
          <span>Ficha do Paciente & Parecer IA</span>
        </button>

        <button
          onClick={() => setActiveTab("CHA2DS2")}
          className={`flex items-center gap-2 px-5 py-3 text-xs md:text-sm font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "CHA2DS2"
              ? "border-[#433fe5] text-white bg-[#433fe5]/15"
              : "border-transparent text-[#f8f7f4]/45 hover:text-[#f8f7f4] hover:bg-[#f8f7f4]/5"
          }`}
        >
          <Calculator className="h-4.5 w-4.5" />
          <span>Escore CHA₂DS₂-VASc</span>
        </button>

        <button
          onClick={() => setActiveTab("CKD_EPI")}
          className={`flex items-center gap-2 px-5 py-3 text-xs md:text-sm font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "CKD_EPI"
              ? "border-[#433fe5] text-white bg-[#433fe5]/15"
              : "border-transparent text-[#f8f7f4]/45 hover:text-[#f8f7f4] hover:bg-[#f8f7f4]/5"
          }`}
        >
          <Layers className="h-4.5 w-4.5" />
          <span>Filtração Glomerular (CKD-EPI)</span>
        </button>

        <button
          onClick={() => setActiveTab("LDL")}
          className={`flex items-center gap-2 px-5 py-3 text-xs md:text-sm font-bold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === "LDL"
              ? "border-[#433fe5] text-white bg-[#433fe5]/15"
              : "border-transparent text-[#f8f7f4]/45 hover:text-[#f8f7f4] hover:bg-[#f8f7f4]/5"
          }`}
        >
          <Activity className="h-4.5 w-4.5" />
          <span>LDL Calculado (Friedewald)</span>
        </button>
      </div>

      {/* RENDER ACTIVE TAB */}
      {activeTab === "ANALYSIS" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="analysis-tab-content">
          {/* Patient Form Input (5 cols) */}
          <div className="lg:col-span-5 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md space-y-5">
            <div className="flex items-center gap-2 border-b border-[#f8f7f4]/10 pb-3">
              <div className="p-1.5 bg-[#433fe5]/10 text-[#433fe5] rounded">
                <FileText className="h-4 w-4" />
              </div>
              <h4 className="font-bold text-[#f8f7f4] text-sm md:text-base font-syne">Informações Clínicas do Paciente</h4>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Nome Completo</label>
                <input
                  type="text"
                  value={patientData.name}
                  onChange={(e) => setPatientData({ ...patientData, name: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5] placeholder-[#f8f7f4]/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Idade (Anos)</label>
                <input
                  type="number"
                  value={patientData.age}
                  onChange={(e) => setPatientData({ ...patientData, age: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Gênero</label>
                <select
                  value={patientData.gender}
                  onChange={(e) => setPatientData({ ...patientData, gender: e.target.value })}
                  className="w-full px-3 py-2.5 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                >
                  <option value="Masculino" className="bg-[#111113]">Masculino</option>
                  <option value="Feminino" className="bg-[#111113]">Feminino</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Pressão Sistólica (mmHg)</label>
                <input
                  type="number"
                  value={patientData.systolicBP}
                  onChange={(e) => setPatientData({ ...patientData, systolicBP: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Pressão Diastólica (mmHg)</label>
                <input
                  type="number"
                  value={patientData.diastolicBP}
                  onChange={(e) => setPatientData({ ...patientData, diastolicBP: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Creatinina Sérica (mg/dL)</label>
                <input
                  type="text"
                  value={patientData.creatinine}
                  onChange={(e) => setPatientData({ ...patientData, creatinine: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Peso (kg)</label>
                <input
                  type="number"
                  value={patientData.weight}
                  onChange={(e) => setPatientData({ ...patientData, weight: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>
            </div>

            {/* Comorbidities checkboxes */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase">Comorbidades Cadastradas</label>
              <div className="grid grid-cols-2 gap-2 text-xs font-semibold text-[#f8f7f4]/80">
                <label className="flex items-center gap-2 p-2 bg-[#0c0c0e] hover:bg-[#f8f7f4]/5 border border-[#f8f7f4]/10 rounded-lg cursor-pointer">
                  <input
                    type="checkbox"
                    checked={patientData.comorbidities.has}
                    onChange={() => handleCheckboxChange("has")}
                    className="accent-[#433fe5]"
                  />
                  <span>Hipertensão (HAS)</span>
                </label>

                <label className="flex items-center gap-2 p-2 bg-[#0c0c0e] hover:bg-[#f8f7f4]/5 border border-[#f8f7f4]/10 rounded-lg cursor-pointer">
                  <input
                    type="checkbox"
                    checked={patientData.comorbidities.dm}
                    onChange={() => handleCheckboxChange("dm")}
                    className="accent-[#433fe5]"
                  />
                  <span>Diabetes (DM2)</span>
                </label>

                <label className="flex items-center gap-2 p-2 bg-[#0c0c0e] hover:bg-[#f8f7f4]/5 border border-[#f8f7f4]/10 rounded-lg cursor-pointer">
                  <input
                    type="checkbox"
                    checked={patientData.comorbidities.ic}
                    onChange={() => handleCheckboxChange("ic")}
                    className="accent-[#433fe5]"
                  />
                  <span>Insuf. Cardíaca (IC)</span>
                </label>

                <label className="flex items-center gap-2 p-2 bg-[#0c0c0e] hover:bg-[#f8f7f4]/5 border border-[#f8f7f4]/10 rounded-lg cursor-pointer">
                  <input
                    type="checkbox"
                    checked={patientData.comorbidities.drc}
                    onChange={() => handleCheckboxChange("drc")}
                    className="accent-[#433fe5]"
                  />
                  <span>Doença Renal (DRC)</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Notas, Sintomas ou Clínicas Adicionais</label>
              <textarea
                value={patientData.symptoms}
                onChange={(e) => setPatientData({ ...patientData, symptoms: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-xs text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
              />
            </div>

            <button
              onClick={runPatientAnalysis}
              disabled={isAnalyzing}
              className="w-full bg-[#433fe5] hover:bg-[#322fbe] disabled:bg-[#111113] disabled:text-[#f8f7f4]/40 disabled:border-[#f8f7f4]/10 disabled:cursor-not-allowed text-white font-mono font-bold py-3.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98"
            >
              {isAnalyzing ? (
                <>
                  <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Gerando Relatório de Decisão IA...</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-4.5 w-4.5 text-yellow-300" />
                  <span>Gerar Relatório de Decisão IA</span>
                </>
              )}
            </button>
          </div>

          {/* AI Decision Result (7 cols) */}
          <div className="lg:col-span-7 flex flex-col bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md min-h-[400px]">
            <div className="flex items-center justify-between border-b border-[#f8f7f4]/10 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-[#433fe5]/10 text-[#433fe5] rounded-lg">
                  <Sparkles className="h-4.5 w-4.5" />
                </div>
                <div>
                  <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base">Análise e Parecer Clínico da IA</h4>
                  <p className="text-[10px] text-[#f8f7f4]/40 font-mono">Gerado em tempo real por gemini-3.5-flash</p>
                </div>
              </div>
            </div>

            {isAnalyzing ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-4">
                <div className="h-12 w-12 rounded-xl bg-[#433fe5]/10 flex items-center justify-center relative">
                  <div className="absolute inset-0 rounded-xl border-2 border-[#433fe5] animate-ping opacity-25" />
                  <Sparkles className="h-6 w-6 text-[#433fe5] animate-pulse" />
                </div>
                <div>
                  <h5 className="font-bold text-[#f8f7f4]">Theo IA está cruzando dados...</h5>
                  <p className="text-[#f8f7f4]/50 text-xs max-w-sm mx-auto mt-1 leading-relaxed">
                    Analisando clearance renal, interações farmacológicas, diretrizes brasileiras da SBC e SBD para traçar condutas adequadas.
                  </p>
                </div>
              </div>
            ) : reportResult ? (
              <div className="flex-1 overflow-y-auto text-[#f8f7f4]/90 prose prose-invert max-w-none text-sm leading-relaxed" id="gemini-report-output">
                {renderMarkdown(reportResult)}
              </div>
            ) : analysisError ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-rose-400 bg-rose-500/10 rounded-xl border border-rose-500/20">
                <AlertTriangle className="h-8 w-8 text-rose-400 mb-2" />
                <h5 className="font-bold">Erro de Processamento</h5>
                <p className="text-xs max-w-md mx-auto mt-1">{analysisError}</p>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-[#f8f7f4]/40 space-y-3">
                <div className="p-4 bg-[#0c0c0e] rounded-full border border-[#f8f7f4]/5">
                  <Activity className="h-8 w-8 text-[#f8f7f4]/35" />
                </div>
                <h5 className="font-bold text-[#f8f7f4]/60">Aguardando envio dos parâmetros</h5>
                <p className="text-xs max-w-sm mx-auto leading-relaxed">
                  Preencha os dados do paciente à esquerda e clique no botão para gerar um parecer analítico completo sobre doses, metas de pressão e recomendações baseadas em evidências.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. CHA2DS2-VASC CALCULATOR VIEW */}
      {activeTab === "CHA2DS2" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="cha2ds2-tab-content">
          <div className="lg:col-span-7 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md space-y-5">
            <div className="flex items-center justify-between border-b border-[#f8f7f4]/10 pb-3">
              <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base">Mapeamento de Fatores de Risco</h4>
              <button
                onClick={resetCha}
                className="text-xs font-mono font-bold text-[#f8f7f4]/40 hover:text-[#f8f7f4] flex items-center gap-1 cursor-pointer transition-colors"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Limpar</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors">
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">Insuficiência Cardíaca Congestiva</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Disfunção de VE, FE reduzida ou preservada (+1)</p>
                </div>
                <input
                  type="checkbox"
                  checked={chaParams.chf}
                  onChange={() => setChaParams({ ...chaParams, chf: !chaParams.chf })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors">
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">Hipertensão Arterial</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Tratada ou não tratada (+1)</p>
                </div>
                <input
                  type="checkbox"
                  checked={chaParams.htn}
                  onChange={() => setChaParams({ ...chaParams, htn: !chaParams.htn })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors">
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">Idade ≥ 75 Anos</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Fator de alto risco etário (+2)</p>
                </div>
                <input
                  type="checkbox"
                  checked={chaParams.age75}
                  onChange={() => setChaParams({ ...chaParams, age75: !chaParams.age75, age65: !chaParams.age75 ? false : chaParams.age65 })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors">
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">Diabetes Mellitus</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Diabetes tipo 1 ou tipo 2 (+1)</p>
                </div>
                <input
                  type="checkbox"
                  checked={chaParams.dm}
                  onChange={() => setChaParams({ ...chaParams, dm: !chaParams.dm })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors">
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">AVC, AIT ou Embolismo</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Histórico prévio de evento isquêmico (+2)</p>
                </div>
                <input
                  type="checkbox"
                  checked={chaParams.stroke}
                  onChange={() => setChaParams({ ...chaParams, stroke: !chaParams.stroke })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors">
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">Doença Vascular</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Histórico de IAM, DAOP ou placa na aorta (+1)</p>
                </div>
                <input
                  type="checkbox"
                  checked={chaParams.vascular}
                  onChange={() => setChaParams({ ...chaParams, vascular: !chaParams.vascular })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>

              <label className={`flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors ${chaParams.age75 ? "opacity-30 select-none pointer-events-none" : ""}`}>
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">Idade 65 a 74 Anos</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Risco moderado por idade (+1)</p>
                </div>
                <input
                  type="checkbox"
                  disabled={chaParams.age75}
                  checked={chaParams.age65}
                  onChange={() => setChaParams({ ...chaParams, age65: !chaParams.age65 })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer transition-colors">
                <div className="space-y-0.5">
                  <span className="text-sm font-bold text-[#f8f7f4]/90">Gênero Feminino</span>
                  <p className="text-[10px] text-[#f8f7f4]/45">Fator de gênero (+1 se escore basal ≥ 1)</p>
                </div>
                <input
                  type="checkbox"
                  checked={chaParams.female}
                  onChange={() => setChaParams({ ...chaParams, female: !chaParams.female })}
                  className="h-4.5 w-4.5 accent-[#433fe5] rounded"
                />
              </label>
            </div>
          </div>

          <div className="lg:col-span-5 flex flex-col justify-between bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md">
            <div className="space-y-4">
              <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base border-b border-[#f8f7f4]/10 pb-3">Escore Final e Conduta</h4>

              <div className="text-center py-6 bg-[#0c0c0e] rounded-2xl border border-[#f8f7f4]/5 relative overflow-hidden">
                <span className="text-xs font-bold text-[#f8f7f4]/40 uppercase tracking-widest block font-mono">Pontuação Total</span>
                <span className="text-6xl font-black font-syne text-[#433fe5] block mt-1 animate-pulse">
                  {chaScore}
                </span>
                <span className="text-xs font-bold text-[#f8f7f4]/55 mt-2 block">pontos</span>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-[#f8f7f4]/40 uppercase tracking-wider block font-mono">Conduta Diagnóstica Sugerida</span>
                <div className={`p-4 rounded-xl border leading-relaxed text-xs md:text-sm font-medium ${
                  getChaRecommendation(chaScore, chaParams.female).variant === "danger"
                    ? "bg-rose-500/15 text-rose-300 border-rose-500/35"
                    : getChaRecommendation(chaScore, chaParams.female).variant === "warning"
                    ? "bg-amber-500/15 text-amber-300 border-amber-500/35"
                    : "bg-emerald-500/15 text-emerald-300 border-emerald-500/35"
                }`}>
                  {getChaRecommendation(chaScore, chaParams.female).text}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#f8f7f4]/10 text-[11px] text-[#f8f7f4]/40 flex items-start gap-1.5 leading-relaxed font-medium">
              <Info className="h-4 w-4 text-[#f8f7f4]/35 shrink-0" />
              <span>O escore CHA₂DS₂-VASc serve para estimar o risco anual de acidente vascular cerebral em pacientes com fibrilação atrial não-valvar.</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. CKD-EPI VIEW */}
      {activeTab === "CKD_EPI" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="ckdepi-tab-content">
          <div className="lg:col-span-7 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md space-y-5">
            <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base border-b border-[#f8f7f4]/10 pb-3">Parâmetros Bioquímicos e Demográficos</h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Creatinina Sérica (mg/dL)</label>
                <input
                  type="text"
                  value={ckdParams.creatinine}
                  onChange={(e) => setCkdParams({ ...ckdParams, creatinine: e.target.value })}
                  placeholder="Ex: 1.1"
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Idade (Anos)</label>
                <input
                  type="number"
                  value={ckdParams.age}
                  onChange={(e) => setCkdParams({ ...ckdParams, age: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Gênero Biológico</label>
                <select
                  value={ckdParams.gender}
                  onChange={(e) => setCkdParams({ ...ckdParams, gender: e.target.value })}
                  className="w-full px-3 py-2.5 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                >
                  <option value="Feminino" className="bg-[#111113]">Feminino</option>
                  <option value="Masculino" className="bg-[#111113]">Masculino</option>
                </select>
              </div>

              <div className="flex items-center">
                <label className="flex items-center gap-2 mt-4 p-3 border border-[#f8f7f4]/10 rounded-xl hover:bg-[#f8f7f4]/5 cursor-pointer w-full">
                  <input
                    type="checkbox"
                    checked={ckdParams.raceBlack}
                    onChange={() => setCkdParams({ ...ckdParams, raceBlack: !ckdParams.raceBlack })}
                    className="accent-[#433fe5]"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-[#f8f7f4]/80 block">Etnia Preta (Fator Clássico CKD-EPI)</span>
                    <span className="text-[10px] text-[#f8f7f4]/40">Aplica multiplicador de 1.159</span>
                  </div>
                </label>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 flex flex-col justify-between bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md">
            <div className="space-y-4">
              <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base border-b border-[#f8f7f4]/10 pb-3">Filtração Glomerular Estimada (eGFR)</h4>

              {gfrResult ? (
                <div className="space-y-4">
                  <div className="text-center py-6 bg-[#0c0c0e] rounded-2xl border border-[#f8f7f4]/5">
                    <span className="text-xs font-bold text-[#f8f7f4]/40 uppercase tracking-widest block font-mono">eGFR Estimado</span>
                    <span className="text-5xl font-black font-syne text-[#433fe5] block mt-1 animate-pulse">
                      {gfrResult.gfr}
                    </span>
                    <span className="text-xs font-bold text-[#f8f7f4]/50 mt-2 block">mL / min / 1.73 m²</span>
                  </div>

                  <div className="p-4 bg-[#433fe5]/15 border border-[#433fe5]/30 rounded-xl space-y-1">
                    <span className="text-xs font-bold text-[#433fe5] uppercase tracking-wider block font-mono">{gfrResult.stage}</span>
                    <p className="text-xs text-[#f8f7f4]/80 font-semibold">{gfrResult.desc}</p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-[#f8f7f4]/50 leading-relaxed font-medium">Por favor, preencha os parâmetros para obter o resultado.</p>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-[#f8f7f4]/10 text-[11px] text-[#f8f7f4]/40 flex items-start gap-1.5 leading-relaxed font-medium">
              <Info className="h-4 w-4 text-[#f8f7f4]/35 shrink-0" />
              <span>A equação CKD-EPI é a recomendada pela KDIGO para estimativa da filtração glomerular basal a partir da Creatinina sérica.</span>
            </div>
          </div>
        </div>
      )}

      {/* 4. LDL CALCULATOR VIEW */}
      {activeTab === "LDL" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="ldl-tab-content">
          <div className="lg:col-span-7 bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md space-y-5">
            <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base border-b border-[#f8f7f4]/10 pb-3">Dados do Perfil Lipídico</h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Colesterol Total (mg/dL)</label>
                <input
                  type="number"
                  value={ldlParams.totalChol}
                  onChange={(e) => setLdlParams({ ...ldlParams, totalChol: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">HDL-C (mg/dL)</label>
                <input
                  type="number"
                  value={ldlParams.hdl}
                  onChange={(e) => setLdlParams({ ...ldlParams, hdl: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#f8f7f4]/50 uppercase mb-1.5">Triglicerídeos (mg/dL)</label>
                <input
                  type="number"
                  value={ldlParams.triglycerides}
                  onChange={(e) => setLdlParams({ ...ldlParams, triglycerides: e.target.value })}
                  className="w-full px-3 py-2 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-lg text-sm text-[#f8f7f4] focus:outline-none focus:ring-1 focus:ring-[#433fe5] focus:border-[#433fe5]"
                />
              </div>
            </div>

            {parseFloat(ldlParams.triglycerides) > 400 && (
              <div className="p-3.5 bg-amber-500/15 border border-amber-500/30 text-amber-300 rounded-xl text-xs flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Aviso Clínico Importante:</span>
                  <p className="mt-0.5 font-medium leading-relaxed">A fórmula de Friedewald perde a precisão quando os triglicerídeos ultrapassam 400 mg/dL. Em casos severos, prefira a mensuração direta do LDL-C.</p>
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-5 flex flex-col justify-between bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md">
            <div className="space-y-4">
              <h4 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base border-b border-[#f8f7f4]/10 pb-3">LDL-C Estimado</h4>

              {ldlResult !== null ? (
                <div className="space-y-4">
                  <div className="text-center py-6 bg-[#0c0c0e] rounded-2xl border border-[#f8f7f4]/5">
                    <span className="text-xs font-bold text-[#f8f7f4]/40 uppercase tracking-widest block font-mono">LDL-C Calculado</span>
                    <span className="text-5xl font-black font-syne text-[#433fe5] block mt-1 animate-pulse">
                      {ldlResult}
                    </span>
                    <span className="text-xs font-bold text-[#f8f7f4]/50 mt-2 block">mg / dL</span>
                  </div>

                  <div className="p-4 bg-[#0c0c0e] rounded-xl space-y-1.5 border border-[#f8f7f4]/10 text-xs text-[#f8f7f4]/70 font-medium">
                    <span className="font-bold text-[#f8f7f4] block">Fórmula Utilizada:</span>
                    <p className="font-mono bg-[#111113] border border-[#f8f7f4]/10 px-2.5 py-1 rounded inline-block text-[11px] text-[#433fe5]">LDL-C = CT - HDL-C - (TG / 5)</p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-[#f8f7f4]/50 leading-relaxed font-medium">Insira valores válidos de colesterol para estimar o LDL-C.</p>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-[#f8f7f4]/10 text-[11px] text-[#f8f7f4]/40 flex items-start gap-1.5 leading-relaxed font-medium">
              <Info className="h-4 w-4 text-[#f8f7f4]/35 shrink-0" />
              <span>O cálculo clássico de LDL-C é amplamente empregado na triagem lipídica inicial, devendo ser interpretado junto à classificação de risco do paciente.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
