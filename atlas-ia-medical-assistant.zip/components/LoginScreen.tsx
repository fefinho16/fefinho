"use client";

import React, { useState } from "react";
import { KeyRound, ShieldCheck, Sparkles, UserCheck } from "lucide-react";
import { motion } from "motion/react";

interface LoginScreenProps {
  onLoginSuccess: () => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [crm, setCrm] = useState("123456-SP");
  const [password, setPassword] = useState("atlas123");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!crm.trim() || !password.trim()) {
      setError("Por favor, preencha todos os campos.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLoginSuccess();
    }, 800);
  };

  return (
    <div className="min-h-screen bg-[#0c0c0e] text-[#f8f7f4] flex flex-col md:grid md:grid-cols-[1fr_480px] relative overflow-x-hidden font-sans" id="login-container">
      
      {/* Left Visual Column */}
      <section className="relative flex flex-col justify-between p-8 md:p-12 border-b md:border-b-0 md:border-r border-[#f8f7f4]/10 overflow-hidden min-h-[280px] md:min-h-screen" style={{
        background: 'radial-gradient(circle at 10% 20%, rgba(67, 63, 229, 0.15) 0%, transparent 50%), radial-gradient(circle at 90% 80%, rgba(112, 40, 224, 0.1) 0%, transparent 50%)'
      }} id="visual-pane">
        
        {/* Grid overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-20" style={{
          backgroundImage: 'radial-gradient(rgba(248, 247, 244, 0.08) 1px, transparent 1px)',
          backgroundSize: '32px 32px'
        }} />
        
        {/* Brand */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="brand z-10"
        >
          <h1 className="font-syne text-4xl md:text-5xl font-extrabold tracking-tight leading-none text-[#f8f7f4]">
            Atlas<span className="text-[#433fe5] font-light opacity-80">IA</span>
          </h1>
          <span className="brand-meta font-mono text-[10px] md:text-xs uppercase tracking-[0.2em] text-[#433fe5] mt-2 block">
            Clinical Core
          </span>
        </motion.div>

        {/* Status Badge */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="status-badge inline-flex items-center gap-2 font-mono text-[9px] md:text-[10px] uppercase tracking-wider px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-sm w-fit z-10 mt-8 md:mt-0"
        >
          <ShieldCheck className="h-3.5 w-3.5" />
          <span>Servidor Seguro Ativo</span>
        </motion.div>
      </section>

      {/* Right Auth Column */}
      <section className="bg-[#111113] p-8 md:p-16 flex flex-col justify-center relative min-h-[calc(100vh-280px)] md:min-h-screen" id="auth-pane">
        <div className="max-w-md w-full mx-auto flex flex-col justify-center h-full">
          
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="auth-header mb-8 md:mb-12"
          >
            <span className="label-pill font-mono text-[10px] uppercase tracking-widest text-[#433fe5] mb-3 block">
              Plataforma Médica Cognitiva
            </span>
            <h2 className="font-syne text-3xl md:text-4xl font-extrabold tracking-tight mb-3 text-[#f8f7f4]">
              Acesse sua conta
            </h2>
            <p className="text-[#f8f7f4]/60 text-sm leading-relaxed">
              Portal integrado de apoio ao diagnóstico, estudo e cálculo clínico.
            </p>
          </motion.div>

          {error && (
            <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded text-xs font-medium font-mono">
              {error}
            </div>
          )}

          <motion.form 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            onSubmit={handleSubmit} 
            className="space-y-6" 
            id="login-form"
          >
            <div className="form-group">
              <div className="form-label-row flex justify-between items-center mb-2">
                <label className="font-mono text-[10px] uppercase tracking-wider text-[#f8f7f4]/60">
                  Registro Profissional (CRM ou e-mail)
                </label>
              </div>
              <div className="input-wrapper relative">
                <UserCheck className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[#f8f7f4]/40" />
                <input
                  type="text"
                  required
                  value={crm}
                  onChange={(e) => {
                    setCrm(e.target.value);
                    setError("");
                  }}
                  placeholder="Ex: 123456-SP"
                  className="w-full bg-transparent border border-[#f8f7f4]/10 text-[#f8f7f4] pl-11 pr-4 py-3.5 rounded focus:outline-none focus:border-[#433fe5] text-sm transition-colors placeholder:text-[#f8f7f4]/30"
                />
              </div>
            </div>

            <div className="form-group">
              <div className="form-label-row flex justify-between items-center mb-2">
                <label className="font-mono text-[10px] uppercase tracking-wider text-[#f8f7f4]/60">
                  Chave de Acesso Protegida
                </label>
                <a href="#" className="font-mono text-[10px] text-[#433fe5] hover:underline" onClick={(e) => e.preventDefault()}>
                  Esqueceu a chave?
                </a>
              </div>
              <div className="input-wrapper relative">
                <KeyRound className="absolute left-3.5 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[#f8f7f4]/40" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  placeholder="Sua senha de segurança"
                  className="w-full bg-transparent border border-[#f8f7f4]/10 text-[#f8f7f4] pl-11 pr-4 py-3.5 rounded focus:outline-none focus:border-[#433fe5] text-sm transition-colors placeholder:text-[#f8f7f4]/30"
                />
              </div>
            </div>

            <div className="alert bg-amber-500/5 border border-amber-500/20 p-4 rounded mb-6 flex gap-3 text-amber-400">
              <div className="alert-content">
                <span className="block font-mono text-[10px] uppercase tracking-widest text-amber-400 mb-1">💡 Homologação</span>
                <p className="text-xs text-amber-400/80 leading-relaxed">
                  CRM: <code className="font-mono bg-amber-500/10 px-1.5 py-0.5 rounded text-amber-300">123456-SP</code> | Senha: <code className="font-mono bg-amber-500/10 px-1.5 py-0.5 rounded text-amber-300">atlas123</code>
                </p>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#433fe5] hover:bg-[#322fbe] disabled:bg-[#433fe5]/50 text-white font-mono font-bold py-4 uppercase tracking-wider rounded flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              {loading ? (
                <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>Autenticar no Sistema</span>
                  <Sparkles className="h-4 w-4" />
                </>
              )}
            </button>
          </motion.form>

          <footer className="mt-12 md:absolute md:bottom-6 md:left-16 md:right-16 flex justify-between text-[#f8f7f4]/20 font-mono text-[9px] uppercase tracking-wider">
            <p>© 2026 ATLAS IA</p>
            <p>V3.5.0-RELEASE</p>
          </footer>
        </div>
      </section>
    </div>
  );
}
