"use client";

import React, { useState } from "react";
import {
  BookOpen,
  Search,
  ExternalLink,
  ChevronRight,
  MessageSquare,
  Sparkles,
  FileText,
  BadgeAlert,
  ArrowRight,
  RotateCcw,
} from "lucide-react";
import { motion } from "motion/react";

type ScreenType = "login" | "dashboard" | "diretrizes" | "ambulatorio" | "theo" | "estudos";

interface DiretrizesScreenProps {
  setScreen: (screen: ScreenType) => void;
  setPreloadedPrompt: (prompt: string) => void;
}

export default function DiretrizesScreen({ setScreen, setPreloadedPrompt }: DiretrizesScreenProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<"TODAS" | "SBC" | "SBD" | "AHA" | "ESC" | "OUTROS">("TODAS");

  const categories = [
    { id: "TODAS", label: "Todas" },
    { id: "SBC", label: "SBC (Brasil)" },
    { id: "SBD", label: "SBD (Diabetes)" },
    { id: "AHA", label: "AHA (EUA)" },
    { id: "ESC", label: "ESC (Europa)" },
    { id: "OUTROS", label: "OMS & Outros" },
  ];

  const guidelines = [
    {
      id: "g1",
      institution: "SBC",
      title: "Diretriz Brasileira de Hipertensão Arterial — 2026",
      summary: "Define metas terapêuticas rígidas (< 130/80 mmHg para a maioria dos pacientes, incluindo diabéticos e coronariopatas). Recomenda início de tratamento com terapia combinada dupla para hipertensos estágio 1 de alto risco ou estágio 2.",
      highlights: [
        "Início precoce de terapia combinada dupla.",
        "Meta PA < 130x80 mmHg para alto risco cardiovascular.",
        "Reforço de MAPA ou MRPA para confirmação diagnóstica.",
      ],
      year: "2026",
      impact: "Alto Impacto Clínico",
      impactColor: "bg-rose-500/15 text-rose-300 border-rose-500/25",
    },
    {
      id: "g2",
      institution: "SBD",
      title: "Diretriz da Sociedade Brasileira de Diabetes — 2025/2026",
      summary: "Atualização de terapia tripla. Recomenda inibidores de SGLT2 (iSGLT2) e agonistas do receptor de GLP-1 (aGLP-1) como primeira linha para diabéticos tipo 2 com doença cardiovascular estabelecida, insuficiência cardíaca ou doença renal crônica.",
      highlights: [
        "iSGLT2 em pacientes com IC (Frações de ejeção reduzida ou preservada).",
        "Associação rápida de iSGLT2 e Metformina no paciente de alto risco renal.",
        "Uso de aGLP-1 focado em proteção cardiovascular e controle ponderal.",
      ],
      year: "2025",
      impact: "Alto Impacto Clínico",
      impactColor: "bg-rose-500/15 text-rose-300 border-rose-500/25",
    },
    {
      id: "g3",
      institution: "AHA",
      title: "ACC/AHA Guidelines for High Blood Cholesterol — 2024",
      summary: "Diretriz norte-americana focada em prevenção secundária. Define metas de LDL-C extremamente baixas (< 55 mg/dL) para pacientes de muito alto risco e introduz recomendação classe I para o uso precoce de Ezetimiba em associação a Estatinas de alta potência.",
      highlights: [
        "Meta de LDL-C < 55 mg/dL em pacientes pós-IAM.",
        "Estatina de alta potência (Atorvastatina 40-80mg ou Rosuvastatina 20-40mg).",
        "Associação precoce de Ezetimiba se meta não for atingida em 4 a 12 semanas.",
      ],
      year: "2024",
      impact: "Moderado Impacto",
      impactColor: "bg-amber-500/15 text-amber-300 border-amber-500/25",
    },
    {
      id: "g4",
      institution: "ESC",
      title: "ESC Guidelines for the Management of Acute Coronary Syndromes — 2025",
      summary: "Consenso europeu sobre o manejo da Síndrome Coronariana Aguda. Foco na duração da dupla antiagregação plaquetária (DAPT), sugerindo encurtamento para 1 a 3 meses em pacientes com alto risco de sangramento, seguido por monoterapia com Clopidogrel ou Ticagrelor.",
      highlights: [
        "DAPT reduzida para 1-3 meses se alto risco de sangramento.",
        "Monoterapia preferencial com inibidores P2Y12 pós-DAPT.",
        "Estratégia invasiva precoce (< 24h) para NSTE-ACS de alto risco.",
      ],
      year: "2025",
      impact: "Alto Impacto Clínico",
      impactColor: "bg-rose-500/15 text-rose-300 border-rose-500/25",
    },
    {
      id: "g5",
      institution: "OUTROS",
      institutionLabel: "OMS",
      title: "OMS: Guideline for the Pharmacological Treatment of Hypertension in Adults",
      summary: "Guia global focado em atenção primária para países de média e baixa renda. Recomenda início de tratamento com qualquer uma das três classes de medicamentos: tiazídicos, bloqueadores de canais de cálcio (BCC) ou iECA/BRA.",
      highlights: [
        "Início de tratamento farmacológico em PA ≥ 140/90 mmHg.",
        "Flexibilidade de classes de primeira linha.",
        "Foco em adesão terapêutica e simplificação de posologias (combinações de dose fixa).",
      ],
      year: "2024",
      impact: "Atenção Primária",
      impactColor: "bg-blue-500/15 text-blue-300 border-blue-500/25",
    },
  ];

  const handleAskTheo = (guidelineTitle: string) => {
    const promptText = `Olá Theo! Gostaria de esclarecer uma dúvida sobre a seguinte diretriz: "${guidelineTitle}". Quais são as principais armadilhas práticas ou contraindicações que devo ficar atento ao aplicar suas recomendações no ambulatório?`;
    setPreloadedPrompt(promptText);
    setScreen("theo");
  };

  const filteredGuidelines = guidelines.filter((g) => {
    const matchesCategory = selectedCategory === "TODAS" || g.institution === selectedCategory;
    const matchesSearch =
      g.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.institution.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto pb-16 text-[#f8f7f4]" id="diretrizes-container">
      {/* Banner */}
      <div className="bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-6 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6" id="diretrizes-intro-banner">
        <div className="space-y-1.5 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#433fe5]/15 text-[#f8f7f4]/90 text-xs font-semibold border border-[#433fe5]/30">
            <FileText className="h-3.5 w-3.5" />
            <span>Biblioteca de Evidências Clínicas</span>
          </div>
          <h3 className="text-lg md:text-xl font-bold text-white font-syne">
            Acesso Rápido a Consensos Médicos
          </h3>
          <p className="text-xs md:text-sm text-[#f8f7f4]/60 font-medium leading-relaxed">
            Navegue pelos consensos vigentes das maiores sociedades do país e do exterior. Clique no botão de integração para tirar dúvidas imediatas com a Inteligência Artificial Theo IA.
          </p>
        </div>

        <div className="relative shrink-0 md:w-80">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#f8f7f4]/45">
            <Search className="h-4 w-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Pesquise por termo (ex: Hipertensão, LDL, SGLT2)..."
            className="w-full pl-9 pr-4 py-2.5 bg-[#0c0c0e] border border-[#f8f7f4]/15 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-[#433fe5] text-[#f8f7f4] transition-all placeholder-[#f8f7f4]/35"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none" id="category-tabs">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              selectedCategory === cat.id
                ? "bg-[#433fe5] text-white shadow-md shadow-[#433fe5]/25"
                : "bg-[#111113] text-[#f8f7f4]/50 hover:text-[#f8f7f4] border border-[#f8f7f4]/10 hover:bg-[#f8f7f4]/5"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Grid of Guidelines */}
      <div className="grid grid-cols-1 gap-6" id="guidelines-list">
        {filteredGuidelines.length > 0 ? (
          filteredGuidelines.map((g, idx) => (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={g.id}
              className="bg-[#111113] border border-[#f8f7f4]/10 rounded-2xl p-5 md:p-6 shadow-md hover:border-[#f8f7f4]/20 transition-all space-y-4"
            >
              {/* Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#f8f7f4]/10 pb-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-xl bg-[#0c0c0e] text-[#f8f7f4]/90 flex items-center justify-center font-mono font-bold text-sm tracking-wide shrink-0 border border-[#f8f7f4]/15">
                    {g.institutionLabel || g.institution}
                  </div>
                  <div>
                    <h4 className="text-base md:text-lg font-bold text-white leading-snug font-syne">
                      {g.title}
                    </h4>
                    <p className="text-xs text-[#f8f7f4]/40 font-semibold mt-0.5 font-mono">
                      Sociedade de Origem: <span className="text-[#433fe5] font-bold">{g.institution}</span> • Publicado em <span className="text-[#f8f7f4]/70 font-bold">{g.year}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold uppercase px-2.5 py-1 rounded-lg border ${g.impactColor}`}>
                    {g.impact}
                  </span>
                </div>
              </div>

              {/* Summary and Highlights */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-7 space-y-2">
                  <h5 className="text-xs font-bold text-[#f8f7f4]/40 uppercase tracking-wider font-mono">Resumo do Consenso</h5>
                  <p className="text-[#f8f7f4]/80 text-sm md:text-base leading-relaxed font-medium">
                    {g.summary}
                  </p>
                </div>

                <div className="lg:col-span-5 bg-[#0c0c0e] border border-[#f8f7f4]/5 rounded-xl p-4 space-y-3">
                  <h5 className="text-xs font-bold text-[#f8f7f4]/45 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                    <BadgeAlert className="h-4 w-4 text-[#433fe5]" />
                    <span>Pontos de Prática / Destaques</span>
                  </h5>
                  <ul className="space-y-2 text-xs md:text-sm text-[#f8f7f4]/75 font-medium">
                    {g.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <ChevronRight className="h-4 w-4 text-[#433fe5] shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#f8f7f4]/10">
                <a
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#f8f7f4]/45 hover:text-[#f8f7f4] transition-colors font-mono"
                >
                  <span>Acessar PDF original da diretriz</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>

                <button
                  onClick={() => handleAskTheo(g.title)}
                  className="bg-[#433fe5]/10 hover:bg-[#433fe5]/20 text-white font-bold text-xs py-2.5 px-4 rounded-xl transition-all cursor-pointer flex items-center gap-2 active:scale-95 border border-[#433fe5]/30 font-mono"
                >
                  <MessageSquare className="h-3.5 w-3.5 text-[#433fe5]" />
                  <span>Consultar Theo IA sobre esta Diretriz</span>
                  <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-12 bg-[#111113] rounded-2xl border border-[#f8f7f4]/10 space-y-3">
            <div className="text-[#f8f7f4]/35 text-4xl">🔍</div>
            <h4 className="font-bold text-[#f8f7f4]/80">Nenhuma diretriz encontrada</h4>
            <p className="text-[#f8f7f4]/40 text-xs max-w-md mx-auto">
              {"Tente redefinir seus filtros ou pesquisar termos mais genéricos como 'Hipertensão', 'LDL', 'SGLT2' ou 'Cardio'."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
