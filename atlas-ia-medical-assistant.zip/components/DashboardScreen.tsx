"use client";

import React from "react";
import {
  Activity,
  Award,
  BookOpen,
  Calendar,
  Clock,
  ExternalLink,
  FileSpreadsheet,
  Heart,
  HeartPulse,
  MessageSquare,
  Sparkles,
  TrendingUp,
  UserCheck,
} from "lucide-react";
import { motion } from "motion/react";

type ScreenType = "login" | "dashboard" | "diretrizes" | "ambulatorio" | "theo" | "estudos";

interface DashboardScreenProps {
  setScreen: (screen: ScreenType) => void;
}

export default function DashboardScreen({ setScreen }: DashboardScreenProps) {
  const currentUtcTime = "2026-07-09 22:39:00"; // Based on context or current UTC time format

  // Clinical performance metrics
  const stats = [
    {
      title: "Pacientes Hoje",
      value: "14",
      change: "+3 vs. ontem",
      icon: UserCheck,
      color: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    },
    {
      title: "Consultas Realizadas",
      value: "8",
      change: "57% concluído",
      icon: Activity,
      color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    },
    {
      title: "Escore de Estudo",
      value: "84%",
      change: "+5% esta semana",
      icon: Award,
      color: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
    },
    {
      title: "Consultas ao Theo IA",
      value: "27",
      change: "Uso ativo hoje",
      icon: MessageSquare,
      color: "bg-violet-500/10 text-violet-400 border-violet-500/20",
    },
  ];

  // Dummy patient list for the active clinic shift
  const patients = [
    {
      id: 1,
      name: "Mariana Costa de Souza",
      age: "67 anos",
      status: "Aguardando",
      reason: "Reavaliação de Hipertensão Arterial Resistente e Diabetes",
      time: "14:15",
      avatarBg: "bg-amber-500/10 text-amber-400",
    },
    {
      id: 2,
      name: "Arnaldo Pires Ramos",
      age: "74 anos",
      status: "Em Atendimento",
      reason: "Ajuste de dose de Enoxaparina por ClCr reduzido (34 ml/min)",
      time: "14:30",
      avatarBg: "bg-[#433fe5]/10 text-[#433fe5]",
    },
    {
      id: 3,
      name: "Beatriz Oliveira Santos",
      age: "59 anos",
      status: "Agendado",
      reason: "Nova prescrição de antidiabéticos e análise de dislipidemia",
      time: "15:00",
      avatarBg: "bg-[#f8f7f4]/10 text-[#f8f7f4]/80",
    },
  ];

  // Latest clinical news & guideline updates
  const updates = [
    {
      tag: "SBC 2026",
      title: "Atualização da Diretriz Brasileira de Hipertensão Arterial",
      description: "Novas recomendações para início precoce de terapia combinada tripla em pacientes de alto risco.",
      type: "Diretrizes",
    },
    {
      tag: "SBD / ADA",
      title: "Algoritmo de Insulina e iSGLT2 no Paciente Cardiopata",
      description: "Consenso reforça papel dos inibidores de SGLT2 independentemente da HbA1c para pacientes com IC.",
      type: "Consenso",
    },
    {
      tag: "Estudo Clínico",
      title: "Resultados do Novo Ensaio de Segurança de Anticoagulantes",
      description: "Doses ajustadas em idosos com insuficiência renal crônica moderada demonstraram redução significativa de sangramentos maiores.",
      type: "Evidência",
    },
  ];

  return (
    <div className="p-4 md:p-8 space-y-6 max-w-7xl mx-auto pb-16 text-[#f8f7f4]" id="dashboard-container">
      {/* Clinician Welcome Hero */}
      <div className="bg-gradient-to-r from-[#433fe5] to-[#7028e0] rounded-2xl p-6 md:p-8 text-white relative overflow-hidden shadow-xl shadow-[#433fe5]/10 border border-[#f8f7f4]/10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-72 h-72 bg-white/5 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/10 text-white text-xs font-semibold backdrop-blur-sm">
              <Sparkles className="h-3.5 w-3.5 text-yellow-300 animate-pulse" />
              <span>Copiloto de Decisão Clínica Ativo</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight font-syne">
              Bem-vindo ao Atlas IA, Dr. Lucas
            </h1>
            <p className="text-indigo-100 text-xs md:text-sm max-w-xl leading-relaxed">
              Sua central de inteligência médica unificada. Consulte consensos atualizados, calcule dosagens farmacológicas e interaja com o assistente cognitivo Theo IA.
            </p>
          </div>

          <button
            onClick={() => setScreen("ambulatorio")}
            className="bg-white hover:bg-[#f8f7f4] text-[#433fe5] font-mono font-bold py-3.5 px-6 rounded-xl transition-all shadow-lg flex items-center gap-2 text-sm cursor-pointer whitespace-nowrap active:scale-[0.98]"
          >
            <Activity className="h-4.5 w-4.5 animate-pulse" />
            <span>Iniciar Ambulatório</span>
          </button>
        </div>
      </div>

      {/* Grid: KPI Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="dashboard-stats-grid">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={stat.title}
              className="bg-[#111113] border border-[#f8f7f4]/10 rounded-xl p-4 shadow-md transition-all flex flex-col justify-between hover:border-[#433fe5]/30 group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] md:text-xs font-bold text-[#f8f7f4]/40 uppercase tracking-wider">
                  {stat.title}
                </span>
                <div className={`p-2 rounded-lg border ${stat.color}`}>
                  <Icon className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-3">
                <span className="text-xl md:text-2xl font-bold text-[#f8f7f4] font-syne">
                  {stat.value}
                </span>
                <p className="text-[10px] md:text-xs text-[#f8f7f4]/50 font-semibold mt-0.5">
                  {stat.change}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Grid: Schedule and Updates */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-content-grid">
        {/* Patient Schedule Widget (7 cols) */}
        <div className="lg:col-span-7 bg-[#111113] border border-[#f8f7f4]/10 rounded-xl p-5 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-[#f8f7f4]/10 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-[#433fe5]/10 text-[#433fe5] rounded-lg border border-[#433fe5]/20">
                <Calendar className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base">
                  Fila do Ambulatório
                </h3>
                <p className="text-xs text-[#f8f7f4]/50">Atendimentos programados para hoje</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#f8f7f4]/60 bg-[#0c0c0e] px-2.5 py-1 rounded border border-[#f8f7f4]/10 font-mono">
              <Clock className="h-3.5 w-3.5 text-[#f8f7f4]/40" />
              <span>22:39 UTC</span>
            </div>
          </div>

          <div className="space-y-3">
            {patients.map((patient) => (
              <div
                key={patient.id}
                className="p-4 border border-[#f8f7f4]/5 rounded-xl hover:border-[#433fe5]/20 hover:bg-[#f8f7f4]/2 transition-all flex items-start justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  <div className={`h-10 w-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${patient.avatarBg}`}>
                    {patient.name.split(" ").slice(0, 2).map(n => n[0]).join("")}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-[#f8f7f4] text-sm md:text-base">
                        {patient.name}
                      </span>
                      <span className="text-xs text-[#f8f7f4]/60 bg-[#f8f7f4]/10 px-2 py-0.5 rounded-full font-mono">
                        {patient.age}
                      </span>
                    </div>
                    <p className="text-xs text-[#f8f7f4]/70 mt-1 font-medium">
                      <span className="font-semibold text-[#433fe5]">Queixa/Motivo:</span> {patient.reason}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0 flex flex-col items-end justify-between h-full space-y-2">
                  <span className="text-xs font-mono font-bold text-[#f8f7f4]/80 bg-[#0c0c0e] px-2 py-1 rounded border border-[#f8f7f4]/5">
                    {patient.time}
                  </span>
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                    patient.status === "Aguardando" ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" :
                    patient.status === "Em Atendimento" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                    "bg-[#f8f7f4]/10 text-[#f8f7f4]/60 border border-[#f8f7f4]/10"
                  }`}>
                    {patient.status}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={() => setScreen("ambulatorio")}
            className="w-full text-center text-xs font-mono font-bold text-[#433fe5] hover:text-[#322fbe] bg-[#433fe5]/5 hover:bg-[#433fe5]/10 py-3 rounded-lg border border-[#433fe5]/10 transition-colors cursor-pointer"
          >
            Ver todos os pacientes e calculadoras integradas
          </button>
        </div>

        {/* Clinical Guideline Updates (5 cols) */}
        <div className="lg:col-span-5 bg-[#111113] border border-[#f8f7f4]/10 rounded-xl p-5 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-[#f8f7f4]/10 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-[#433fe5]/10 text-[#433fe5] rounded-lg border border-[#433fe5]/20">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-bold text-[#f8f7f4] font-syne text-sm md:text-base">
                  Destaques e Alertas IA
                </h3>
                <p className="text-xs text-[#f8f7f4]/50">Consensos médicos e novidades científicas</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {updates.map((update, i) => (
              <div key={i} className="space-y-1.5 border-b border-[#f8f7f4]/5 last:border-0 pb-3 last:pb-0">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold text-[#433fe5] bg-[#433fe5]/10 px-2 py-0.5 rounded border border-[#433fe5]/15 uppercase tracking-wider">
                    {update.tag}
                  </span>
                  <span className="text-[10px] text-[#f8f7f4]/40 font-semibold font-mono">
                    {update.type}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-[#f8f7f4] hover:text-[#433fe5] transition-colors cursor-pointer flex items-center gap-1 leading-tight">
                  {update.title}
                  <ExternalLink className="h-3 w-3 inline opacity-55" />
                </h4>
                <p className="text-xs text-[#f8f7f4]/60 leading-relaxed font-medium">
                  {update.description}
                </p>
              </div>
            ))}
          </div>

          <button
            onClick={() => setScreen("diretrizes")}
            className="w-full text-center text-xs font-mono font-bold text-[#f8f7f4]/60 hover:text-[#f8f7f4] bg-[#0c0c0e] hover:bg-[#111113] py-3 rounded-lg border border-[#f8f7f4]/10 transition-colors cursor-pointer"
          >
            Pesquisar acervo de Diretrizes Médicas
          </button>
        </div>
      </div>

      {/* AI Assistant integration callout */}
      <div className="bg-[#111113] border border-[#f8f7f4]/10 rounded-xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-[#433fe5]/15 border border-[#433fe5]/30 flex items-center justify-center text-[#433fe5] shrink-0 shadow-sm shadow-[#433fe5]/10">
            <MessageSquare className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-[#f8f7f4] text-sm md:text-base font-syne">Dúvida rápida sobre conduta ou posologia?</h4>
            <p className="text-xs text-[#f8f7f4]/55 font-medium">Theo IA está disponível para responder baseando-se em diretrizes clínicas nacionais e internacionais.</p>
          </div>
        </div>
        <button
          onClick={() => setScreen("theo")}
          className="bg-[#433fe5] hover:bg-[#322fbe] text-white font-mono font-bold py-2.5 px-5 rounded-lg text-xs transition-all shadow-md hover:shadow-[#433fe5]/20 cursor-pointer active:scale-95 flex items-center gap-1.5 whitespace-nowrap"
        >
          <span>Conversar com Theo</span>
          <Sparkles className="h-3.5 w-3.5 text-yellow-300 animate-pulse" />
        </button>
      </div>
    </div>
  );
}
