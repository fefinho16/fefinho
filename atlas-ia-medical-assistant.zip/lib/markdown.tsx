import React from "react";

export function renderMarkdown(text: string): React.ReactNode {
  if (!text) return null;

  const lines = text.split("\n");
  const elements: React.ReactNode[] = [];
  let currentList: { items: string[]; ordered: boolean } | null = null;
  let currentTable: { headers: string[]; rows: string[][] } | null = null;

  const flushList = (key: string) => {
    if (currentList) {
      const ListTag = currentList.ordered ? "ol" : "ul";
      const listClass = currentList.ordered
        ? "list-decimal ml-6 mb-4 space-y-1 text-gray-700"
        : "list-disc ml-6 mb-4 space-y-1 text-gray-700";
      elements.push(
        <ListTag key={key} className={listClass}>
          {currentList.items.map((item, i) => (
            <li key={i}>{parseInlineMarkdown(item)}</li>
          ))}
        </ListTag>
      );
      currentList = null;
    }
  };

  const flushTable = (key: string) => {
    if (currentTable) {
      elements.push(
        <div key={key} className="overflow-x-auto my-4 rounded-lg border border-gray-200">
          <table className="min-w-full divide-y divide-gray-200 text-sm">
            <thead className="bg-gray-50">
              <tr>
                {currentTable.headers.map((h, i) => (
                  <th
                    key={i}
                    className="px-4 py-3 text-left font-semibold text-gray-700 uppercase tracking-wider"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentTable.rows.map((row, rIndex) => (
                <tr key={rIndex} className={rIndex % 2 === 0 ? "bg-white" : "bg-gray-50/55"}>
                  {row.map((cell, cIndex) => (
                    <td key={cIndex} className="px-4 py-3 text-gray-700 font-medium">
                      {parseInlineMarkdown(cell)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      currentTable = null;
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    // Check for Table Row
    if (line.startsWith("|") && line.endsWith("|")) {
      flushList(`list-before-table-${i}`);
      const parts = line
        .split("|")
        .map((p) => p.trim())
        .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);

      // Check if it's a separator row (e.g., |---|---|)
      const isSeparator = parts.every((p) => p.match(/^-+$/));
      if (isSeparator) {
        continue;
      }

      if (!currentTable) {
        currentTable = { headers: parts, rows: [] };
      } else {
        currentTable.rows.push(parts);
      }
      continue;
    } else {
      flushTable(`table-before-${i}`);
    }

    // Check for bullet list
    const bulletMatch = rawLine.match(/^(\s*)([-*+])\s+(.*)$/);
    if (bulletMatch) {
      const content = bulletMatch[3];
      if (!currentList || currentList.ordered) {
        flushList(`list-before-bullet-${i}`);
        currentList = { items: [content], ordered: false };
      } else {
        currentList.items.push(content);
      }
      continue;
    }

    // Check for ordered list
    const orderMatch = rawLine.match(/^(\s*)(\d+)\.\s+(.*)$/);
    if (orderMatch) {
      const content = orderMatch[3];
      if (!currentList || !currentList.ordered) {
        flushList(`list-before-order-${i}`);
        currentList = { items: [content], ordered: true };
      } else {
        currentList.items.push(content);
      }
      continue;
    }

    // If not a list item, flush existing list
    flushList(`list-before-p-${i}`);

    // Headings
    if (line.startsWith("### ")) {
      elements.push(
        <h3 key={i} className="text-lg font-bold text-slate-800 mt-5 mb-2 leading-snug">
          {parseInlineMarkdown(line.substring(4))}
        </h3>
      );
    } else if (line.startsWith("## ")) {
      elements.push(
        <h2 key={i} className="text-xl font-bold text-slate-900 mt-6 mb-3 border-b border-gray-100 pb-1">
          {parseInlineMarkdown(line.substring(3))}
        </h2>
      );
    } else if (line.startsWith("# ")) {
      elements.push(
        <h1 key={i} className="text-2xl font-bold text-indigo-900 mt-8 mb-4">
          {parseInlineMarkdown(line.substring(2))}
        </h1>
      );
    } else if (line === "") {
      elements.push(<div key={i} className="h-2" />);
    } else {
      elements.push(
        <p key={i} className="text-gray-700 leading-relaxed mb-3 text-sm md:text-base">
          {parseInlineMarkdown(rawLine)}
        </p>
      );
    }
  }

  flushList("list-final");
  flushTable("table-final");

  return <div className="space-y-1">{elements}</div>;
}

function parseInlineMarkdown(text: string): React.ReactNode {
  // Regex for bold (**text**) and code (`text`)
  const parts: React.ReactNode[] = [];
  let tempText = text;
  let keyIdx = 0;

  while (tempText.length > 0) {
    const boldMatch = tempText.match(/\*\*(.*?)\*\*/);
    const codeMatch = tempText.match(/`(.*?)`/);

    const boldIdx = boldMatch && boldMatch.index !== undefined ? boldMatch.index : -1;
    const codeIdx = codeMatch && codeMatch.index !== undefined ? codeMatch.index : -1;

    if (boldIdx === -1 && codeIdx === -1) {
      parts.push(<span key={keyIdx++}>{tempText}</span>);
      break;
    }

    // Determine which comes first
    if (boldIdx !== -1 && (codeIdx === -1 || boldIdx < codeIdx)) {
      if (boldIdx > 0) {
        parts.push(<span key={keyIdx++}>{tempText.substring(0, boldIdx)}</span>);
      }
      parts.push(
        <strong key={keyIdx++} className="font-bold text-slate-900 bg-slate-50 px-0.5 rounded">
          {boldMatch![1]}
        </strong>
      );
      tempText = tempText.substring(boldIdx + boldMatch![0].length);
    } else if (codeIdx !== -1) {
      if (codeIdx > 0) {
        parts.push(<span key={keyIdx++}>{tempText.substring(0, codeIdx)}</span>);
      }
      parts.push(
        <code key={keyIdx++} className="bg-gray-100 text-[#7028e0] font-mono text-xs px-1.5 py-0.5 rounded border border-gray-200">
          {codeMatch![1]}
        </code>
      );
      tempText = tempText.substring(codeIdx + codeMatch![0].length);
    }
  }

  return <>{parts}</>;
}
