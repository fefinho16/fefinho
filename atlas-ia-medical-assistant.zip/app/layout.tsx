import type {Metadata} from 'next';
import { Inter, Space_Mono, Syne } from 'next/font/google';
import './globals.css'; // Global styles

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  weight: ['300', '400', '600'],
});

const spaceMono = Space_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['400', '700'],
});

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  weight: ['800'],
});

export const metadata: Metadata = {
  title: 'Atlas IA - Clinical Core',
  description: 'Portal de Apoio ao Diagnóstico e Estudo Clínico',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="pt-br" className={`${inter.variable} ${spaceMono.variable} ${syne.variable}`}>
      <body suppressHydrationWarning className="font-sans antialiased text-slate-800">
        {children}
      </body>
    </html>
  );
}
