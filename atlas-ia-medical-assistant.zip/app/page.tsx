"use client";

import React, { useState } from "react";
import LoginScreen from "../components/LoginScreen";
import Sidebar from "../components/Sidebar";
import DashboardScreen from "../components/DashboardScreen";
import AmbulatorioScreen from "../components/AmbulatorioScreen";
import DiretrizesScreen from "../components/DiretrizesScreen";
import TheoScreen from "../components/TheoScreen";
import EstudosScreen from "../components/EstudosScreen";

type ScreenType = "login" | "dashboard" | "diretrizes" | "ambulatorio" | "theo" | "estudos";

export default function Page() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>("login");
  const [preloadedPrompt, setPreloadedPrompt] = useState("");

  const handleLoginSuccess = () => {
    setCurrentScreen("dashboard");
  };

  const clearPreloadedPrompt = () => {
    setPreloadedPrompt("");
  };

  if (currentScreen === "login") {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <Sidebar currentScreen={currentScreen} setScreen={setCurrentScreen}>
      {currentScreen === "dashboard" && (
        <DashboardScreen setScreen={setCurrentScreen} />
      )}
      {currentScreen === "ambulatorio" && (
        <AmbulatorioScreen />
      )}
      {currentScreen === "diretrizes" && (
        <DiretrizesScreen
          setScreen={setCurrentScreen}
          setPreloadedPrompt={setPreloadedPrompt}
        />
      )}
      {currentScreen === "theo" && (
        <TheoScreen
          preloadedPrompt={preloadedPrompt}
          clearPreloadedPrompt={clearPreloadedPrompt}
        />
      )}
      {currentScreen === "estudos" && (
        <EstudosScreen />
      )}
    </Sidebar>
  );
}
